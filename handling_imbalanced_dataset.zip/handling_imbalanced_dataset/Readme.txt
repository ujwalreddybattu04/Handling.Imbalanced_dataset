Upsampling and downsampling are techniques used in data preprocessing, especially in the context of machine learning, signal processing, or image processing, to adjust the size or distribution of data.

1. Upsampling
Definition: Increasing the size or resolution of the data by adding more samples or data points.
Purpose:
In machine learning, upsampling is used to address class imbalance by replicating or generating more samples of the minority class.

2. Downsampling
Definition: Reducing the size or resolution of the data by removing samples or data points.
Purpose:
In machine learning, downsampling is used to balance class distribution by reducing the majority class size.